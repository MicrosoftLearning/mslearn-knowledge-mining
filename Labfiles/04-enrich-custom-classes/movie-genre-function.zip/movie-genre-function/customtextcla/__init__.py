import azure.functions as func
import json, requests, time, os, logging
from requests.exceptions import RequestException

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        body = json.dumps(req.get_json())
    except ValueError:
        return func.HttpResponse(
             "Invalid body",
             status_code=400
        )
    
    if body:
        result = compose_response(body)
        return func.HttpResponse(result, mimetype="application/json")
    else:
        return func.HttpResponse(
             "Invalid body",
             status_code=400
        )

def compose_response(json_data):
    values = json.loads(json_data)['values']

    # Prepare the Output before the loop
    results = {}
    results["values"] = []

    for value in values:
        outputRecord = transform_value(value)
        if outputRecord is not None:
            results["values"].append(outputRecord)
    return json.dumps(results, ensure_ascii=False)

def transform_value(value):
    try:
        recordId = value['recordId']
    except KeyError as error:
        logging.error(f"Missing 'recordId' field in value: {value}")
        return None

    # Validate the inputs
    try:         
        assert ('data' in value), "'data' field is required."
        data = value['data']        
        assert ('lang' in data), "'lang' language field is required in 'data' object."        
        assert ('text' in data), "'text' corpus field is required in 'data' object."
    except AssertionError as error:
        logging.error(f"Error in input validation: {error}")
        return {
            "recordId": recordId,
            "data": {},
            "errors": [{"message": "Error:" + str(error)}]
        }

    try:
        result = get_classifications(value)
        return {
            "recordId": recordId,
            "data": {
                "text": result
            }
        }
    except RequestException as error:
        logging.error(f"Error in get_classifications: {error}")
        return {
            "recordId": recordId,
            "errors": [{"message": "Could not complete operation for record."}]
        }

# Function to submit the analysis job towards the Text Analytics (TA) API
def get_classifications(value):
    language = str(value['data']['lang'])
    corpus = str(value['data']['text'])
    endpoint = os.environ["TA_ENDPOINT"]
    key = os.environ["TA_KEY"]
    project_name = os.environ["PROJECT_NAME"]
    deployment = os.environ["DEPLOYMENT"]
    body = {
        'displayName': 'Extracting custom text classification',
        'analysisInput': {
            'documents': [{'id': '1', 'language': language, 'text': corpus}]
        },
        'tasks': [{
            'kind': 'CustomMultiLabelClassification',
            'taskName': 'Multi Label Classification',
            'parameters': {'project-name': project_name, 'deployment-name': deployment}
        }]
    }
    body_json = json.dumps(body)
    header = {'Ocp-Apim-Subscription-Key': key}

    response_job = requests.post(endpoint, data=body_json, headers=header)
    response_job.raise_for_status()  # Raise exception for 4xx or 5xx status codes
    print('Response is:', response_job.headers)

    jobURL = response_job.headers["operation-location"]
    max_retries = 5
    retry_delay = 2
    for retry in range(max_retries):
        response = requests.get(jobURL, headers=header)
        response.raise_for_status()  # Raise exception for 4xx or 5xx status codes
        dict = response.json()
        if dict['status'] == 'succeeded':
            classifications = dict['tasks']['items'][0]['results']['documents'][0]['class']
            return classifications
        elif dict['status'] == 'failed':
            raise RuntimeError("Text Analytics job failed.")
        
        time.sleep(retry_delay)
        retry_delay *= 2  # Exponential backoff for retries
    
    raise TimeoutError("Text Analytics job timed out after maximum retries.")